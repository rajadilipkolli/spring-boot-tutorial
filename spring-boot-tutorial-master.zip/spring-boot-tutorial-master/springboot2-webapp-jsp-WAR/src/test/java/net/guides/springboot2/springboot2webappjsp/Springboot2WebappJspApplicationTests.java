package net.guides.springboot2.springboot2webappjsp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class Springboot2WebappJspApplicationTests {

	@Test
	public void contextLoads() {
	}

}
