package net.guides.springboot.springboot2jpaauditing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class Springboot2JpaAuditingApplicationTests {

	@Test
	public void contextLoads() {
	}

}
