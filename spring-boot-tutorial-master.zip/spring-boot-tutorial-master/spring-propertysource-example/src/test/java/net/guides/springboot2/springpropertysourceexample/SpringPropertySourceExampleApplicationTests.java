package net.guides.springboot2.springpropertysourceexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringPropertySourceExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
