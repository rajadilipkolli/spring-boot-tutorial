package net.guides.springboot2.springboot2swagger3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot2Swagger2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
