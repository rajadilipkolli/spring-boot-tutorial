package net.guides.springboot2.springboot2annotationconfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class Springboot2AnnotationConfigApplicationTests {

	@Test
	public void contextLoads() {
	}

}
