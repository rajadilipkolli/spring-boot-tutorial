package net.guides.springboot2.springboottestingexamples;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SpringbootTestingExamplesApplicationTests {

	@Test
	public void contextLoads() {
	}

}
