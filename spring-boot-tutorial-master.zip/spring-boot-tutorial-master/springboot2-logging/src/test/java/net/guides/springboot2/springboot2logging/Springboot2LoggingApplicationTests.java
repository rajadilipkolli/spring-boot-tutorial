package net.guides.springboot2.springboot2logging;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class Springboot2LoggingApplicationTests {

	@Test
	public void contextLoads() {
	}

}
