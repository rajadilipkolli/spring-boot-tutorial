package net.javaguides.springboot.fileuploaddownload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SpringbootUploadDownloadFileApplicationTests {

	@Test
	public void contextLoads() {
	}

}
