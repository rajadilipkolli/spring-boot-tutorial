package net.guides.springboot.springbootcrudrestapivalidation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SpringbootCrudRestApiValidationApplicationTests {

	@Test
	public void contextLoads() {
	}

}
