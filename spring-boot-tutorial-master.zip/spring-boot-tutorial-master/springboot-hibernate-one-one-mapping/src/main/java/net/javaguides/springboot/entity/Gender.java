package net.javaguides.springboot.entity;

public enum Gender {
	MALE, FEMALE

}
