package net.guides.springboot.springbootasyncexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SpringbootAsyncApplicationTests {

	@Test
	public void contextLoads() {
	}

}
